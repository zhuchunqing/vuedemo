export { default } from './src/index.vue';
