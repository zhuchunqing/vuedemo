export { default } from './src/tabbar.vue';
